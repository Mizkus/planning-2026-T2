# PS1: Discrete Planning

Install dependencies and reproduce all three tasks:

```bash
python3 -m pip install -r requirements.txt
python3 main.py
```

The script works independently of the current directory. It saves GIFs beside
main.py, and figures, paths, configuration space and CSV tables in results/.

The required animations are point_solve.gif and rod_solve.gif. Additional GIFs
show the A* runs. Definitions and explanations are in the separately submitted
Mizkus_ps1.pdf.

The folder name uses the Git username Mizkus. If your course uniquename differs,
rename the folder, ZIP archive and report PDF accordingly before submitting.

